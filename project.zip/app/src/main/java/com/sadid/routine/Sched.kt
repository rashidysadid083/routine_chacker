package com.sadid.routine

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Sched {
    fun schedule(c: Context) {
        val (h, m) = Store.time(c)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }

    fun notifyNow(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("daily", "দৈনিক রুটিন", NotificationManager.IMPORTANCE_HIGH)
        )
        Store.resetIfNewDay(c)
        val list = Store.pick(Store.load(c), Calendar.getInstance())
        val short = if (list.isEmpty()) "আজ কোনো ক্লাস নেই" else list.joinToString(", ") { it.subject }
        val big = if (list.isEmpty()) short else list.joinToString("\n") { k ->
            val room = if (k.room.isBlank()) "" else " (${k.room})"
            val todo = k.checks.filter { !it.done }.joinToString("") { "\n   ☐ " + it.text }
            "${k.start}-${k.end} ${k.subject}$room$todo"
        }
        val open = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "daily")
            .setSmallIcon(R.drawable.ic_notif)
            .setColor(0xFF1565C0.toInt())
            .setContentTitle("আজকের ক্লাস")
            .setContentText(short)
            .setStyle(Notification.BigTextStyle().bigText(big))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.notifyNow(c)
        Sched.schedule(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.schedule(c)
    }
}
