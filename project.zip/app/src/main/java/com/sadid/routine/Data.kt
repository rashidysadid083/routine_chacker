package com.sadid.routine

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

data class Check(val text: String, val done: Boolean)

// kind: 0 = দৈনিক, 1 = সাপ্তাহিক (day = Calendar.DAY_OF_WEEK), 2 = মাসিক (day = 1..31)
data class Cls(
    val id: Long, val kind: Int, val day: Int, val subject: String,
    val start: String, val end: String, val room: String, val desc: String,
    val checks: List<Check>
)

object Store {
    private fun file(c: Context) = File(c.filesDir, "data.json")

    fun load(c: Context): List<Cls> {
        val f = file(c)
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ck = o.getJSONArray("checks")
                Cls(
                    o.getLong("id"), o.getInt("kind"), o.getInt("day"), o.getString("subject"),
                    o.getString("start"), o.getString("end"), o.getString("room"), o.getString("desc"),
                    (0 until ck.length()).map { j ->
                        val x = ck.getJSONObject(j)
                        Check(x.getString("t"), x.getBoolean("d"))
                    }
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(c: Context, list: List<Cls>) {
        val a = JSONArray()
        list.forEach { k ->
            val ck = JSONArray()
            k.checks.forEach { ck.put(JSONObject().put("t", it.text).put("d", it.done)) }
            a.put(
                JSONObject().put("id", k.id).put("kind", k.kind).put("day", k.day)
                    .put("subject", k.subject).put("start", k.start).put("end", k.end)
                    .put("room", k.room).put("desc", k.desc).put("checks", ck)
            )
        }
        file(c).writeText(a.toString())
    }

    fun time(c: Context): Pair<Int, Int> {
        val p = c.getSharedPreferences("p", Context.MODE_PRIVATE)
        return Pair(p.getInt("h", 7), p.getInt("m", 0))
    }

    fun setTime(c: Context, h: Int, m: Int) {
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putInt("h", h).putInt("m", m).apply()
    }

    // প্রতিদিন নতুন দিনে সব চেকলিস্টের টিক খালি হয়ে যায়
    fun resetIfNewDay(c: Context) {
        val cal = Calendar.getInstance()
        val today = "" + cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.DAY_OF_YEAR)
        val p = c.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (p.getString("last", "") == today) return
        val l = load(c)
        if (l.any { k -> k.checks.any { it.done } }) {
            save(c, l.map { k -> k.copy(checks = k.checks.map { it.copy(done = false) }) })
        }
        p.edit().putString("last", today).apply()
    }

    fun exportText(c: Context): String {
        val f = file(c)
        return if (f.exists()) f.readText() else "[]"
    }

    fun importText(c: Context, s: String): Boolean {
        return try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                o.getLong("id"); o.getInt("kind"); o.getInt("day"); o.getString("subject")
                o.getString("start"); o.getString("end"); o.getString("room"); o.getString("desc")
                val ck = o.getJSONArray("checks")
                for (k in 0 until ck.length()) {
                    val x = ck.getJSONObject(k); x.getString("t"); x.getBoolean("d")
                }
            }
            file(c).writeText(s)
            true
        } catch (e: Exception) {
            false
        }
    }

    // অগ্রাধিকার: মাসিক > সাপ্তাহিক > দৈনিক
    fun pick(all: List<Cls>, cal: Calendar): List<Cls> {
        val dom = cal.get(Calendar.DAY_OF_MONTH)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val m = all.filter { it.kind == 2 && it.day == dom }
        if (m.isNotEmpty()) return m.sortedBy { it.start }
        val w = all.filter { it.kind == 1 && it.day == dow }
        if (w.isNotEmpty()) return w.sortedBy { it.start }
        return all.filter { it.kind == 0 }.sortedBy { it.start }
    }
}
