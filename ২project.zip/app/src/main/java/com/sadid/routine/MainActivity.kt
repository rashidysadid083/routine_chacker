package com.sadid.routine

import android.Manifest
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Store.resetIfNewDay(this)
        Sched.schedule(this)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(this@MainActivity) }
            }
        }
    }
}

val DAYS = listOf(7 to "শনি", 1 to "রবি", 2 to "সোম", 3 to "মঙ্গল", 4 to "বুধ", 5 to "বৃহঃ", 6 to "শুক্র")
val TABS = listOf("আজ", "দৈনিক", "সাপ্তাহিক", "মাসিক")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(ctx: Context) {
    var items by remember { mutableStateOf(Store.load(ctx)) }
    var tab by remember { mutableStateOf(0) }
    val now = Calendar.getInstance()
    var wd by remember { mutableStateOf(now.get(Calendar.DAY_OF_WEEK)) }
    var md by remember { mutableStateOf(now.get(Calendar.DAY_OF_MONTH)) }
    var time by remember { mutableStateOf(Store.time(ctx)) }
    var edit by remember { mutableStateOf<Cls?>(null) }
    var isNew by remember { mutableStateOf(false) }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Store.exportText(ctx).toByteArray()) }
                android.widget.Toast.makeText(ctx, "ব্যাকআপ সেভ হয়েছে", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.widget.Toast.makeText(ctx, "সেভ করা যায়নি", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val txt = try {
                ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) }
            } catch (e: Exception) {
                null
            }
            if (txt != null && Store.importText(ctx, txt)) {
                items = Store.load(ctx)
                android.widget.Toast.makeText(ctx, "ব্যাকআপ লোড হয়েছে", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                android.widget.Toast.makeText(ctx, "ফাইলটা ঠিক নেই", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun commit(l: List<Cls>) {
        items = l
        Store.save(ctx, l)
    }

    val shown = when (tab) {
        0 -> Store.pick(items, Calendar.getInstance())
        1 -> items.filter { it.kind == 0 }
        2 -> items.filter { it.kind == 1 && it.day == wd }
        else -> items.filter { it.kind == 2 && it.day == md }
    }.sortedBy { it.start }
    val day = when (tab) { 2 -> wd; 3 -> md; else -> 0 }
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val exactOk = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("রুটিন রিমাইন্ডার", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                TimePickerDialog(ctx, { _, h, m ->
                    Store.setTime(ctx, h, m)
                    time = Pair(h, m)
                    Sched.schedule(ctx)
                }, time.first, time.second, false).show()
            }) { Text("সময়: " + "%02d:%02d".format(time.first, time.second)) }
            OutlinedButton(onClick = { Sched.notifyNow(ctx) }) { Text("টেস্ট") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("ব্যাটারি") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportL.launch("routine_backup.json") }) { Text("ব্যাকআপ সেভ") }
            OutlinedButton(onClick = { importL.launch(arrayOf("*/*")) }) { Text("ব্যাকআপ লোড") }
        }
        if (!exactOk) {
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                )
            }) { Text("সঠিক সময়ের অ্যালার্মের অনুমতি দাও") }
        }
        TabRow(selectedTabIndex = tab) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        if (tab == 2) {
            LazyRow(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(DAYS) { d ->
                    FilterChip(selected = wd == d.first, onClick = { wd = d.first }, label = { Text(d.second) })
                }
            }
        }
        if (tab == 3) {
            LazyRow(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items((1..31).toList()) { d ->
                    FilterChip(selected = md == d, onClick = { md = d }, label = { Text("$d") })
                }
            }
        }
        if (shown.isEmpty()) {
            Text("কোনো ক্লাস নেই", Modifier.padding(vertical = 16.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.id }) { k ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(k.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(k.start + " - " + k.end + (if (k.room.isBlank()) "" else "  |  " + k.room))
                        if (k.desc.isNotBlank()) Text(k.desc, Modifier.padding(top = 4.dp))
                        k.checks.forEachIndexed { idx, c ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = c.done, onCheckedChange = { v ->
                                    val nc = k.checks.mapIndexed { j, x -> if (j == idx) x.copy(done = v) else x }
                                    commit(items.map { if (it.id == k.id) k.copy(checks = nc) else it })
                                })
                                Text(c.text)
                            }
                        }
                        if (tab != 0) {
                            TextButton(onClick = { isNew = false; edit = k }) { Text("এডিট") }
                        }
                    }
                }
            }
        }
        if (tab != 0) {
            Button(
                onClick = {
                    isNew = true
                    edit = Cls(System.currentTimeMillis(), tab - 1, day, "", "08:00", "08:45", "", "", emptyList())
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ ক্লাস যোগ করো") }
        }
    }

    edit?.let { e ->
        EditDialog(
            init = e,
            canDelete = !isNew,
            onSave = { n ->
                commit(if (isNew) items + n else items.map { if (it.id == n.id) n else it })
                edit = null
            },
            onDelete = {
                commit(items.filter { it.id != e.id })
                edit = null
            },
            onClose = { edit = null }
        )
    }
}

@Composable
fun EditDialog(init: Cls, canDelete: Boolean, onSave: (Cls) -> Unit, onDelete: () -> Unit, onClose: () -> Unit) {
    var sub by remember { mutableStateOf(init.subject) }
    var st by remember { mutableStateOf(init.start) }
    var en by remember { mutableStateOf(init.end) }
    var room by remember { mutableStateOf(init.room) }
    var desc by remember { mutableStateOf(init.desc) }
    var ck by remember { mutableStateOf(init.checks.joinToString("\n") { it.text }) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("ক্লাস") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(sub, { sub = it }, label = { Text("বিষয়") })
                OutlinedTextField(st, { st = it }, label = { Text("শুরু (HH:mm, যেমন 08:00)") })
                OutlinedTextField(en, { en = it }, label = { Text("শেষ (HH:mm)") })
                OutlinedTextField(room, { room = it }, label = { Text("রুম") })
                OutlinedTextField(desc, { desc = it }, label = { Text("ডিসক্রিপশন / নোট") })
                OutlinedTextField(ck, { ck = it }, label = { Text("চেকলিস্ট / অ্যাসাইনমেন্ট (প্রতি লাইনে একটি)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (sub.isNotBlank()) {
                    val old = init.checks.associate { it.text to it.done }
                    val list = ck.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        .map { Check(it, old[it] ?: false) }
                    onSave(init.copy(subject = sub.trim(), start = st.trim(), end = en.trim(),
                        room = room.trim(), desc = desc.trim(), checks = list))
                }
            }) { Text("সেভ") }
        },
        dismissButton = {
            Row {
                if (canDelete) TextButton(onClick = onDelete) { Text("মুছো") }
                TextButton(onClick = onClose) { Text("বাতিল") }
            }
        }
    )
}
